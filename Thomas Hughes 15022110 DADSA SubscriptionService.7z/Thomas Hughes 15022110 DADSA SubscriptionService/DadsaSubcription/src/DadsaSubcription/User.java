
package DadsaSubcription;

import java.util.ArrayList;

/**
 *
 * @author Thomas Hughes 15022110
 */
public class User {

    private String id;
    private String name;
    private int max = 5;
    private int bookedNum = 0;
  
    /**
     * ArrayList for BookedItem
     */
    private ArrayList<BookedItem> bookedItem;

    /**
     *
     * @return
     */
    public int getBookedNum() {//Getter for returning bookednum
        return bookedNum;
    }

    /**
     * Setter for implementing bookedNum to num
     *
     * @param num
     */
    public void setBookedNum(int num) {
        bookedNum = num;

    }

    /**
     * Getter for information returns a String
     *
     * @return s
     */
    public String getInformation() {
        String s;
        s = id + " " + name + " Booked: ";
        //Enhanced for loop for Bookeditem ArrayList
        for (BookedItem item : bookedItem) {
            s += item.getItem().getItemNum() + " ";
        }

        return s;
    }

    /**
     * Getter for returning max
     * @return max
     */
    public int getMax() {
        return max;
    }

    /**
     * Setter for implementing this.max to max
     * @param max
     */
    public void setMax(int max) {
        this.max = max;
    }

    /**
     * returns bookedIem ArrayList
     * @return bookedItem
     */
    public ArrayList<BookedItem> getBookedItem() {//returns bookedIem ArrayList
        return bookedItem;
    }

    
    /**
     * printBookedItem() for printing out the bookedItem ArrayList
     * @param index
     * @return
     */
    public BookedItem printBookedItem(int index) {
        for (int i = 0; i < bookedItem.size(); i++) {
            if (i == index) {
                System.out.println(bookedItem.get(i).toString());
            }
        }
        return null;
    }

    
    /**
     * addBookedItem() to add a bookedItem
     * @param booking
     */
    public void addBookedItem(BookedItem booking) {
        bookedItem.add(booking);

    }
    

    /**  
     * returnBookedItem() removesItem
     * @param booking
     */
    public void returnBookedItem(BookedItem booking) {
        bookedItem.remove(booking);
    }

    
    /**
     * Constructor for id and name
     * @param id
     * @param name
     */
    public User(String id, String name) {
        this.id = id;
        this.name = name;
        bookedItem = new ArrayList<BookedItem>();
    }

    /**
     * Getter to return id
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * Setter implements this.id to id
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Getter to return name 
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Setter implements this.name to name
     * @param name
     */
    public void setName(String name) {//
        this.name = name;
    }

    /**
     * toString method for User class
     * @return this.id + " " + this.name
     */
    @Override
    public String toString() {// 
        return this.id + " " + this.name;
    }

}
