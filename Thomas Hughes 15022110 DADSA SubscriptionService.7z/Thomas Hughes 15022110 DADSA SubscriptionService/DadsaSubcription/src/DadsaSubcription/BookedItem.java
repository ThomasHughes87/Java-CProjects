
package DadsaSubcription;

import java.util.Date;
/**
 *
 * @author Thomas hughes 15022110
 */
public class BookedItem {
    
    /**
     *
     */
    private Item item;

    /**
     *
     */
    private Date date;

    /**
     *
     */
    private User user;
    /**
     * BookedItem constructor for item and date
     * @param item
     * @param date
     * @param user
     */
    public BookedItem(Item item, Date date, User user){
        this.item = item;
        this.date = date;
        this.user = user;
    }

    /**
     * Getter that return user
     * @return user
     */
    public User getUser() {
        return user;
    }

    /**
     * Setter that implements this.user to user
     * @param user
     */
    public void setUser(User user) {
        this.user = user;
    }


    /**
     * BookedItem constructor for date
     * @param date
     */
    public BookedItem(Date date) {
        this.date = date;
    }

    /**
     * Getter that returns date
     * @return
     */
    public Date getDate() {
        return date;
    }
    
    /**
     * Getter that returns item
     * @return
     */
    public Item getItem(){
        return item;
    }

    /**
     * Setter that implements this.item to item
     * @param item
     */
    public void setItem(Item item){
        this.item = item;
    }

    /**
     * Setter that implements this.date to date
     * @param date
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * BookedItem class toString method
     * @return "Booked Item - Item: " + user.toString()+ item.toString() + " Date of booking: " + date.toString()
     */
    @Override
    public String toString() {
        return "Booked Item - Item: " + user.toString() +" \n "+ item.toString() + " Date of booking: " + date.toString()+"\n";
    }
    
    
}
