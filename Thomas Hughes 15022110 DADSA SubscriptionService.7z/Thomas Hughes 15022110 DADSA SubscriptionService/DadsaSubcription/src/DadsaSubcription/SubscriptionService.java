/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DadsaSubcription;

// my imports for my program
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


/**
 *
 * @author trw2-hughes Thomas Hughes 15022110
 */
public class SubscriptionService {

    // My ArrayListes for my users and items
    private static ArrayList<User> users = new ArrayList<User>();
    private static ArrayList<Item> items = new ArrayList<Item>();

   /*  my constants for my ArrayLists so when I add a user or an Item it 
    *  automaticaly asigns them ID numbers that are not in use.
    */
    private static int userID = 11133;
    private static int itemNum = 1343;

    /* Three date objects the first one  Date today = new Date() is to implement
    * a week for the checkExpiry2(). Date date1 = new Date() is for 
    * checkExpiry() for the user to check manually for a Items return.
    * Date date2 = new Date() is for checkExpiry3() so it constanly compares the 
    * present date with the items booking date.
     */
    public static Date today = new Date();
    public static Date date1 = new Date();
    public static Date date2 = new Date();

    /**
     * This is my main method that holds the biggest part of my code
     */
    public static void main(String[] args) {
       
        Scanner sc = new Scanner(System.in);
        int menu = 0;
        System.out.println("Please load test data first!!");

        /* This is my switch statement that selects the parts of the
        * code the user wishes to run from the menu. It is inside 
        * a while loop that keeps running until the user enter 0.
        * Outside of the switch statement i have my scanner input for the switch,
        * and a call to my printmenu() so the menu keeps showing the options  
        * after a task is performed. I also have a call to the checkExpiry3() so
        * with every iteration of the while loop, it checks the expiry of 
        * the booked items with the preenst date and time automatically.
        * 
         */
        while (true) {

            printMenu();
            checkExpiry3();
            menu = sc.nextInt();

            switch (menu) {
                case 0:
                    System.exit(0);
                case 1:
                    LoadTestData();
                    break;
                case 2:
                    addANewUser();
                    break;
                case 3:
                    addANewItem();
                    break;
                case 4:
                    printAllUsers();
                    break;
                case 5:
                    printAllItems();
                    break;
                case 6:
                    bookItem();
                    break;
                case 7:
                    searchItem();
                    break;
                case 8:
                    showInformationOfItem();
                    break;
                case 9:
                    showInformationOfUser();
                    break;
                  case 10:
                   showAllBookedItems();
                    break;
                case 11:
                    week();
                    break;
                case 12:
                    checkExpiry();
                default:
                    System.out.println("Please enter a valid number");

            }
        }

    }

              

    /**
     * week() uses the setTime() to set the Date to show time milliseconds after
     * January 1, 1970 00:00:00 GMT. it also uses getTime() that returns how
     * many milliseconds have passed since January 1, 1970, 00:00:00 GMT. then
     * the SysOutPrnt print the date out using a toString().
     */
    public static void week() {
        today.setTime(today.getTime() + 604800000);
        System.out.println("Today is: " + today.toString());
    }

    /**
     * This is an Algorithm i designed for Checking the Expiry of a booked item.
     * checkExpiry() uses a nested enhanced for loop to iterate through the hole
     * body of code. Then we have an ArrayList called bItems that uses
     * getBookedItem() from the User class that stores all the booked items info
     * in an ArrayList. There's a for loop that iterates through Size of the
     * ArrayList and in the for loop there's a condition, if the date thats
     * counted in milliseconds from 1/1/1970 to present time minus(-) the date of the
     * booked items that are converted in to milliseconds using the getTime(),
     * is equal to 604800000 which is a week in milliseconds, then return booked
     * item and increment the availability of the item by 1 and decrement the
     * users booked items by one.
     */
    public static void checkExpiry() {

        for (User user : users) {
            ArrayList<BookedItem> bItems = user.getBookedItem();
            for (int i = 0; i < bItems.size(); i++) {
                if ((today.getTime() - bItems.get(i).getDate().getTime()) == 604800000) {
                    BookedItem bi = bItems.get(i);
                    user.returnBookedItem(bi);
                    bi.getItem().setAvailable(bi.getItem().getAvailable() + 1);
                    user.setBookedNum(user.getBookedNum() - 1);
                    System.out.printf("User : %s returned item: %availabliltys\n", user.getId(), bi.getItem().getTitle());
                    i--;
                }
            }
        }

    }

    /**
     * checkExpiry2() is the same as checkExpiry() but doesn't print a message
     * and is only run when choosing showInformationOfUser() and
     * showInformationOfItem() so it automatically compares the dates of the
     * booked item and incremented week when the user runs the method.
     */
    public static void checkExpiry2() {

        for (User user : users) {
            ArrayList<BookedItem> bItems = user.getBookedItem();
            for (int i = 0; i < bItems.size(); i++) {
                if ((today.getTime() - bItems.get(i).getDate().getTime()) == 604800000) {
                    BookedItem bi = bItems.get(i);
                    user.returnBookedItem(bi);
                    bi.getItem().setAvailable(bi.getItem().getAvailable() + 1);
                    user.setBookedNum(user.getBookedNum() - 1);
                    i--;
                }
            }
        }

    }

    /**
     * checkExpiry3() is a little different from the previous two
     * checkExpiry()'s because it compares real time with the booked items time
     * it does this because it's been placed in the main methods while loop,
     * just above the switch statement so every time the switch statement is
     * initiated and the while loop iterates the times are compared, so if the
     * program was run for a week you wouldn't have to check the expiry or
     * increment a week it would automatically return the item.
     */
    public static void checkExpiry3() {

        for (User user : users) {
            ArrayList<BookedItem> bItems = user.getBookedItem();
            for (int i = 0; i < bItems.size(); i++) {
                if ((date1.getTime() - bItems.get(i).getDate().getTime()) >= 604800000) {
                    BookedItem bi = bItems.get(i);
                    user.returnBookedItem(bi);
                    bi.getItem().setAvailable(bi.getItem().getAvailable() + 1);
                    user.setBookedNum(user.getBookedNum() - 1);

                    i--;
                }
            }
        }

    }

    /**
     *showAllBookedItems() to print out all the booked Items
     */
    public static void showAllBookedItems(){
    	for (User user : users) {
        ArrayList<BookedItem> bItems = user.getBookedItem();
        for (int i = 0; i < bItems.size(); i++){
            System.out.println(bItems);
            i++;
          }
}
    }
    /**
     * showInformationOfItem() takes in the ItemsID from user input and calls
     * the getInformation() method from the Item class which reads out a String
     * of items ID,the name of the item and how many are available. it also
     * carries the checkExpiry2() to automatically check and items Expiry.
     */
    public static void showInformationOfItem() {

        checkExpiry2();
        Scanner scan = new Scanner(System.in);
        System.out.println("Please input an item ID");
        String itemID = scan.nextLine();
        System.out.println(getAItem(itemID).getInformation());

    }

    /**
     * showInformationOfUser() takes in the UserID from user input and calls the
     * getInformation() method from the User class which reads out a String of
     * User ID,the users name and how many are available and returns what
     * they've booked. it also carries the checkExpiry2()to automatically check
     * and items Expiry.
     */
    public static void showInformationOfUser() {

        checkExpiry2();
        Scanner scn = new Scanner(System.in);
        System.out.println("Please input UserID");
        String userID = scn.nextLine();
        System.out.println(getAUser(userID).getInformation());

    }

    /**
     * searchItem() lets the user search for items by name or by the items ID if
     * any thing other than the valid number or name is entered it prompts a
     * message relaying Sorry, not available.
     */
    public static void searchItem() {
        checkExpiry3();
        // Scanner for input from user
        Scanner search = new Scanner(System.in);
        // Sysouts for the two options
        System.out.println("1. Search by ID");
        System.out.println("2. Search by Title");

        // input form user for ID or Title
        int num = search.nextInt();
        search.nextLine();

        // If user enters 1: Please input the ID
        if (num == 1) {
            System.out.println("Please input the ID:");
            String id = search.nextLine();

            //boolean value for if they input the wrong ID
            boolean state = false;

            /* Enhanced for loop for searching ArrayList if the ID Entered 
             * equals a valid ItemID number
             */
            for (Item item : items) {
                if (item.getItemNum().equals(id)) {
                    System.out.println(item.toString());
                    state = true;
                    break;
                }
            }
            // if state equals false then print out Message
            if (state == false) {
                System.out.println("Sorry, not available!");
            }
            // else if they dont enter 1 must mean 2 Print out message
        } else {
            System.out.println("Please input the Title:");
            String title = search.nextLine();

            boolean state = false;

            /* Enhanced for loop for searching ArrayList if the Title
            * equals a valid Title name
             */
            for (Item item : items) {
                if (item.getTitle().equals(title)) {
                    System.out.println(item.toString());
                    state = true;
                    break;
                }
            }
            // if state equals false then print out Message
            if (state == false) {
                System.out.println("Sorry, not available!");
            }

        }
    }

    /**
     * bookAItem() to check userID and itemID to see if the item is available
     * for booking, also to check the quantity of an item to see if its
     * available. this is the biggest part of my code so i will comment
     * everything separately
     */
    public static void bookItem() {
        checkExpiry2();
        // Scanner for user Bookings
        Scanner scforbooking = new Scanner(System.in);

        String userID;
        // input user ID number from user for bookings
        System.out.println("Please input the user id");
        userID = scforbooking.nextLine();

        // If user exists then input Item id for bookings
        if (isUserAvailable(userID)) {
            System.out.println("Please input the item id");
            String itemID = scforbooking.nextLine();

            // if the item is available call boolean checkUserMax()
            if (isItemAvailable(itemID)) {

                /* checks if the user has booked there max amount of not, calls the
                 * boolean checkUserMax()
                 */
                if (checkUserMax(userID)) {

                    /* checks if the item has been book its max amount of times
                     * it calls the boolean checkUserMax()
                     */
                    if (checkItemMax(itemID)) {

                        //Instance of the User class 
                        User user = getAUser(userID);
                        //Instance of the Item class
                        Item item = getAItem(itemID);
                        
                        /*
                        * These lines of code are for calling methods from the 
                        * user class and the Item class. addBookedItem() adds
                        * booked items and the date they where booked 
                        * to the ArrayList in User. setBookedNum() increments 
                        * the amount the user is allowed to book if the Item
                        * is booked. setAvailable() decrement the availablity
                        * of the choosen item the user has booked.
                        */
                        user.addBookedItem(new BookedItem(item, date2, user));
                        user.setBookedNum(user.getBookedNum() + 1);
                        item.setAvailable(item.getAvailable() - 1);
                        
                        /* This prints out the userID, the ItemID and the date 
                         * when it was booked to the user on the screen
                         */
                        System.out.println("The user " + userID + " has booked the item \n" + itemID + " at " + date2);
                        
                        /*
                         * These FileWriter and BufferedWriter save the bookings
                         * to the Transaction.csv File to keep a record of the 
                         * bookings. they have been put in a try and catch
                         * Exception handler to void errors on the screen
                         */
                        try {
                            FileWriter fstream = new FileWriter("C:\\Users\\KingSpoon\\Documents\\NetBeansProjects\\DadsaSubcription\\src\\DadsaSubcription\\transactions.csv", true);
                            BufferedWriter out = new BufferedWriter(fstream);
                            out.write("the user " + userID + " has booked the item number:" + itemID + " at " + date2 + "\n");
                            out.close();
                        } catch (Exception e) {
                            System.err.println("Error while writing to file: "
                                    + e.getMessage());
                        }
                        
                       /*
                        * The else statement is for if the item has no 
                        * availablity then the itemID is put in to a 
                        * LinkList for user in the Item class that acts like 
                        * a queue and increments the users booking amount.
                        */ 
                    } else {
                        User user = getAUser(userID);
                        getAItem(itemID).reserve(user);
                        user.setBookedNum(user.getBookedNum() + 1);
                        System.out.println("the user " + userID + " has reserved the item " + itemID);

                    }
                    // This it if the user books there max amount of items.
                } else {
                    System.out.println("No space for the user, please start again1");
                }
                
                // This for if the user input an invald item ID.
            } else {
                System.out.println("invalid item id, please start again!");
             }   
            
               // This for if the user inputs an invalid user ID.
            } else {
            System.out.println("invalid user id, please start again!");
        }

       

    }

    
    /**
     * isItemAvailable() to give a boolean value to see if the item is available
     */
    public static boolean isItemAvailable(String id) {
  
        //Enhanced for loop to see if the items are available
        for (Item item : items) {
            if (item.getItemNum().equals(id)) {
                
                // if the items availability is greater than zero return true
                if (item.getAvailable() >= 0) {
                    return true;
                }
                break;
            }

        }
        // if not then return faulse
        return false;
    }

    
    /**
     * isUserAvailable() to give a boolean value to see if the userID is valid
     * and the user exists.
     */
    public static boolean isUserAvailable(String id) {

        boolean state = false;

        for (User user : users) {
            if (user.getId().equals(id)) {
                state = true;
                break;
            }

        }

        return state;
    }

    
    /**
     * checkUserMax()is a boolean method for checking users items limit
     * 
     */
    public static boolean checkUserMax(String id) {
        boolean state = false;
        
        /*
         * if the user booked amount number is less than the max amount return 
         * true
         */
        if (getAUser(id).getBookedNum() < getAUser(id).getMax()) {
            state = true;
        }
        // if not return false
        return state;

    }

    /**
     *
     * checkItemMax(() checks if the item has been book its max amount of times
     */
    public static boolean checkItemMax(String itemid) {

        boolean state = false;

        Item item = getAItem(itemid);
        // if the availabilty is greater than 0 return true
        if (item.getAvailable() > 0) {
            state = true;
        }
        // if not return false
        return state;

    }

    
    /**
     * print out menus for the switch statment
     */
      public static void printMenu() {
        checkExpiry3();
        System.out.println("1: Load Test Data");
        System.out.println("2: Add a new User");
        System.out.println("3: Add a new Item");
        System.out.println("4: Print All Users");
        System.out.println("5: Print All Items");
        System.out.println("6: Book a Item");
        System.out.println("7: Search by ID or Title");
        System.out.println("8: Show information of an Item");
        System.out.println("9: Show information of a User");
        System.out.println("10: Show all booked Items");
        System.out.println("11: Simulate a week");
        System.out.println("12: Check Expiry");
        System.out.println("0: Exit");
        System.out.println("Please input:");

    }

   
    /**
     * addANewUser() method for adding a new user
     */
    public static void addANewUser() {
      
    
        //Scanner for adding user 
        Scanner scforUser = new Scanner(System.in);
        //Sysout for user to enter new name
        System.out.println("Please input a username:");
       

        String name = scforUser.nextLine();
        //This is where the user adds a users name and automatically assigns an 
        //ID to the User in the Arraylist using the toString method
        users.add(new User(Integer.toString(userID), name));

        userID++;
    }

    
    /**
     * addANewItem() method for adding a new item
     */
    public static void addANewItem() {
        //Scanner for adding user
        Scanner scforItem = new Scanner(System.in);
        //Sysout and SysInput for user to enter new Title
        System.out.println("Please input a new item title:");
        String title = scforItem.nextLine();
        
        //Sysout and SysInput for user to enter the availablilty amount
        System.out.println("Please input the quantity for the item:");
        int quantity = scforItem.nextInt();
        
        //This is where the user adds a item title quantity and 
        //automatically assigns an ID to the item in the Arraylist using
        //the toString method
        items.add(new Item(Integer.toString(itemNum), title, quantity));

        itemNum++;
    }

    // method for loading test data 
    /**
     *
     */
    public static void LoadTestData() {
        // Scanners for the member.csv file
        Scanner sc = new Scanner(SubscriptionService.class.getResourceAsStream("member.csv"));
        // Scanners for the Item.csv file
        Scanner sc2 = new Scanner(SubscriptionService.class.getResourceAsStream("item.csv"));

        String s;
        String st;
        String id;
        String name;
        String itemNum;
        String title;
        int available;

        /* this takes in the user name and id number from the csv file and splits
        it using the comer*/
        sc.nextLine();
        while (sc.hasNext()) {
            s = sc.nextLine();
            id = s.split(",")[0];
            name = s.split(",")[1];

            users.add(new User(id, name));

        }

        /* this takes in the item, title and the availbiltity from the csv file
        and splits all three using the comer */
        sc2.nextLine();
        while (sc2.hasNext()) {
            st = sc2.nextLine();
            itemNum = st.split(",")[0];
            title = st.split(",")[1];
            available = Integer.parseInt(st.split(",")[2]);

            items.add(new Item(itemNum, title, available));

        }

        System.out.println("Successful Loading!");

    }

    
    /**
     * printAllUsers() for printing all users From the ArrayList
     */
    public static void printAllUsers() {
        // for loop for printing all users
        for (int i = 0; i < users.size(); i++) {
            System.out.println(users.get(i));
               
        }

    }

    
    /**
     * printAllItems() for printing all items From the ArrayList
     */
    public static void printAllItems() {
        // for loop for printing all users
        for (int i = 0; i < items.size(); i++) {
            System.out.println(items.get(i));
           
        }

    }

    //
    /**
     * getAUser() for returning the UserID
     */
    public static User getAUser(String id) {
        User u = null;
        for (User user : users) {
            if (user.getId().equals(id)) {
                u = user;
            }
        }

        return u;

    }

    
    /**
     * getItem() for returning item ID number
     */
    public static Item getAItem(String id) {

        Item i = null;
        for (Item item : items) {
            if (item.getItemNum().equals(id)) {
                i = item;
            }

        }

        return i;

    }

}
