
package DadsaSubcription;

import java.util.*;

/**
 *
 * @author THomas Hughes 15022110
 */
public class Item {

    private String itemNum;
    public String title;
    private int available;

    /**
     * LinkedList for a queue
     */
    private LinkedList<User> queue = new LinkedList();
   

    /**
     * item Constructor for implementing this.available to available
     * @param available
     */
    public Item(int available) {
        this.available = available;
    }

    /**
     * Getter for information returns info String.
     * Implementing the LinkedList queue
     * @return info
     */
    public String getInformation() {
        String info = itemNum + " " + title + " " + available;
        queue = new LinkedList<User>();
        
         for (User user : queue) {
            info += user.getName() + " ";
        }

        return info;
    }
       


    /**
     * reserve() for adding user to the queue
     * @param user
     */
    public void reserve(User user) {
        queue.add(user);
    }

    /**
     * Item Constructor for implementing this.itemNum to itemNum
     * this.title to title and this.available to available
     * @param itemNum
     * @param title
     * @param available
     */
    public Item(String itemNum, String title, int available) {
        this.itemNum = itemNum;
        this.title = title;
        this.available = available;
    }

    /**
     * Getter for itemNum returns itemNum
     * @return itemNum
     */
    public String getItemNum() {
        return itemNum;
    }

    /**this.itemNum = itemNum
     * Setter for itemNum implements this.itemNum to itemNum
     * @param itemNum
     */
    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    /**
     * Getter for title returns title
     * @return title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Setter for title implements this.title to title
     * @param title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Getter for available returns available
     * @return
     */
    public int getAvailable() {
        return available;
    }

    /**
     * Setter for available implements this.available to available
     * @param available
     */
    public void setAvailable(int available) {
        this.available = available;
    }

    /**
     * Item class toString 
     * @return this.itemNum + " " + this.available + " " + this.title;
     */
    @Override
    public String toString() {
        return this.itemNum + " " + this.available + " " + this.title;
    }

    /**
     * boolean available method if availability is greater than 0 return true 
     * else return false
     * @return true or false
     */
    public boolean IsAvailable() {
        if (available > 0) {
            return true;
        } else {
            return false;
        }

    }

}
