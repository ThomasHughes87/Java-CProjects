This is a variant of the Pintos Operating System for use as part of CNOS module.
